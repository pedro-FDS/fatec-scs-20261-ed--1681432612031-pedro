
OPERADORES = ["+", "-", "*", "/"]

while True:
    pilha = []

    expressao = input("\nDigite a expressão RPN (ou 'sair'): ")

    if expressao.lower() == "sair":
        print("Encerrando...")
        break

    if expressao.strip() == "":
        print("Erro: Digite uma expressão!")
        continue

    itens = expressao.split()

    if len(itens) == 3 and itens[1] in OPERADORES:
        print("Erro: Você não digitou uma operação RPN!")
        continue

    for iten in itens:

        if iten.lstrip("-").replace(".", "", 1).isdigit():   

            if len(pilha) >= 4:
                print("Erro: Pilha cheia! Máximo de 4 números (registradores X, Y, Z, T).")
                break
            pilha.append(float(iten))

        elif iten in OPERADORES:         

            if len(pilha) < 2:
                print("Erro: Operandos insuficientes!")
                break

            x = pilha.pop()   
            y = pilha.pop()   

            if iten == "+":
                pilha.append(y + x)
            elif iten == "-":
                pilha.append(y - x)
            elif iten == "*":
                pilha.append(y * x)
            elif iten == "/":
                if x == 0:
                    print("Erro: Divisão por zero!")
                    break
                pilha.append(y / x)

        else:
            print(f"Erro: '{iten}' não é válido!")
            break

        print("\n--- Pilha atual ---")
        for i in range(len(pilha) - 1, -1, -1):
            posicao = len(pilha) - 1 - i
            if posicao == 0:
                label = "X (topo)"
            elif posicao == 1:
                label = "Y"
            elif posicao == 2:
                label = "Z"
            else:
                label = "T"
            print(f"  {label}: {pilha[i]}")
        print("-------------------")

    else:
        if len(pilha) > 1:
            print("Expressão incompleta. Faltou o operador")
        else:
            print("\nResultado =", pilha[-1])