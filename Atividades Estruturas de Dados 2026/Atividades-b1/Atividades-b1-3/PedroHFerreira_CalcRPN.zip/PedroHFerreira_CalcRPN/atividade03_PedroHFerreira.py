'''*---------------------------------------------------------*
* Fatec São Caetano do Sul                                   *                                            
* Autor: 1681432612031 - Pedro Henrique Ferreira da Silva    *
* Objetivo: Atividade da calculadora RPN                     *
* data: 31/03/2026                                           *
*------------------------------------------------------------*
'''

while True:
    pilha = []
    expressoes = []

    entrada = input("\nDigite uma expressão RPN (ou 'sair'): ")

    if entrada.lower() == "sair":
        print("Encerrando o programa...")
        break

    partes = entrada.split()

    for item in partes:

        # Se for número, guarda nas listas
        if item.isdigit():
            pilha.append(int(item))
            expressoes.append(item)

        else:
            # Pega os dois últimos valores
            n1 = pilha.pop()
            n2 = pilha.pop()

            e1 = expressoes.pop()
            e2 = expressoes.pop()

            # Faz a operação
            if item == "+":
                conta = n2 + n1
            elif item == "-":
                conta = n2 - n1
            elif item == "*":
                conta = n2 * n1
            elif item == "/":
                conta = n2 / n1

            # Guarda resultado
            pilha.append(conta)

            # Monta expressão normal
            nova = "(" + e2 + " " + item + " " + e1 + ")"
            expressoes.append(nova)

        # Mostra estado da pilha (simplificado)
        topo = pilha[-1] if len(pilha) > 0 else 0
        meio = pilha[-2] if len(pilha) > 1 else 0
        base = pilha[-3] if len(pilha) > 2 else 0

        print("Topo:", topo, "| Meio:", meio, "| Base:", base)

    print("\nResultado final:", pilha[-1])
    print("Expressão normal:", expressoes[-1])